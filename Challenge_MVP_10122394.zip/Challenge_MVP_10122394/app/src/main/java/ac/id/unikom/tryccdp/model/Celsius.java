package ac.id.unikom.tryccdp.model;

import androidx.lifecycle.MutableLiveData;

public class Celsius {

    private static Celsius instance;

    private double celsiusValue;
    private MutableLiveData<String> fahrenheit = new MutableLiveData<>();
    private MutableLiveData<String> reamur = new MutableLiveData<>();

    private Celsius() {}

    public static Celsius getInstance() {
        if (instance == null) {
            instance = new Celsius();
        }
        return instance;
    }

    public void setCelsius(double value) {
        this.celsiusValue = value;
    }

    public void toFahrenheit() {
        double f = (celsiusValue * 9 / 5) + 32;
        fahrenheit.setValue(String.valueOf(f));
    }

    public void toReamur() {
        double r = celsiusValue * 4 / 5;
        reamur.setValue(String.valueOf(r));
    }

    public MutableLiveData<String> getFahrenheit() {
        return fahrenheit;
    }

    public MutableLiveData<String> getReamur() {
        return reamur;
    }
}
