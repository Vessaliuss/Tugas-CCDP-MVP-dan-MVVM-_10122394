package ac.id.unikom.tryccdp.presenter;

import ac.id.unikom.tryccdp.model.Celsius;
import ac.id.unikom.tryccdp.view.MainView;

public class MainPresenter {

    private MainView view;
    private Celsius model;

    public MainPresenter(MainView view) {
        this.view = view;
        this.model = Celsius.getInstance();
    }

    public void calculateTemperature() {
        String celsiusText = view.getCelsius();
        if (celsiusText.isEmpty()) {
            celsiusText = "0";
        }

        double value = Double.parseDouble(celsiusText);
        model.setCelsius(value);
        model.toFahrenheit();
        model.toReamur();
    }
}
