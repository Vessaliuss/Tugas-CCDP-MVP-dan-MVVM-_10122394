package ac.id.unikom.tryccdp.view;

public interface MainView {
    String getCelsius();
}
