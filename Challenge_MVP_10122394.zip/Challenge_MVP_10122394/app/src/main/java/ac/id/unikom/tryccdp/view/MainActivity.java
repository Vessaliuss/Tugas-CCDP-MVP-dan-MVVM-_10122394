package ac.id.unikom.tryccdp.view;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import ac.id.unikom.tryccdp.R;
import ac.id.unikom.tryccdp.model.Celsius;
import ac.id.unikom.tryccdp.presenter.MainPresenter;

public class MainActivity extends AppCompatActivity implements MainView {

    private EditText celsius, fahrenheit, reamur;
    private MainPresenter presenter;
    private Celsius model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        presenter = new MainPresenter(this);
        model = Celsius.getInstance();

        initView();
        observeModel();
    }

    private void observeModel() {
        model.getFahrenheit().observe(this,
                f -> fahrenheit.setText(f));

        model.getReamur().observe(this,
                r -> reamur.setText(r));
    }

    private void initView() {
        celsius = findViewById(R.id.celsius);
        fahrenheit = findViewById(R.id.fahrenheit);
        reamur = findViewById(R.id.reamur);

        celsius.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                presenter.calculateTemperature();
            }

            @Override public void beforeTextChanged(CharSequence s, int i, int j, int k) {}
            @Override public void onTextChanged(CharSequence s, int i, int j, int k) {}
        });
    }

    @Override
    public String getCelsius() {
        return celsius.getText().toString();
    }
}
