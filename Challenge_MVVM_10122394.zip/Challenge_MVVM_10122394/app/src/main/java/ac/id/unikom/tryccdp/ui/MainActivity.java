package ac.id.unikom.tryccdp.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import java.text.DecimalFormat;

import ac.id.unikom.tryccdp.R;
import ac.id.unikom.tryccdp.biodata.Biodata;
import ac.id.unikom.tryccdp.viewmodel.MainViewModel;

public class MainActivity extends AppCompatActivity {

    private EditText celsius, fahrenheit, reamur;
    private MainViewModel viewModel;
    private final DecimalFormat decimalFormat = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi ViewModel
        viewModel = new ViewModelProvider(this)
                .get(MainViewModel.class);

        Log.d("BIODATA", "Nama  : " + Biodata.getNama());
        Log.d("BIODATA", "NIM   : " + Biodata.getNIM());
        Log.d("BIODATA", "Kelas : " + Biodata.getKelas());
        Log.d("BIODATA", "Prodi : " + Biodata.getProdi());
        Log.d("BIODATA", "Univ  : " + Biodata.getUniversitas());

        initView();
        observeViewModel();
    }

    private void observeViewModel() {
        viewModel.getFahrenheit().observe(this, value -> {
            try {
                double v = Double.parseDouble(value);
                fahrenheit.setText(decimalFormat.format(v));
            } catch (Exception e) {
                fahrenheit.setText(value);
            }
        });

        viewModel.getReamur().observe(this, value -> {
            try {
                double v = Double.parseDouble(value);
                reamur.setText(decimalFormat.format(v));
            } catch (Exception e) {
                reamur.setText(value);
            }
        });
    }

    private void initView() {
        celsius = findViewById(R.id.celsius);
        fahrenheit = findViewById(R.id.fahrenheit);
        reamur = findViewById(R.id.reamur);

        celsius.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                String input = s.toString();

                // Jika kosong, anggap 0
                if (input.isEmpty()) {
                    viewModel.calculateTemperature("0");
                    return;
                }

                // Validasi angka
                try {
                    Double.parseDouble(input);
                    viewModel.calculateTemperature(input);
                } catch (NumberFormatException e) {
                    Log.e("MVVM", "Input tidak valid: " + input);
                }
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });
    }
}
