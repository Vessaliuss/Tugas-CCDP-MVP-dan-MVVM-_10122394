package ac.id.unikom.tryccdp.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import ac.id.unikom.tryccdp.model.Celsius;

public class MainViewModel extends ViewModel {

    private Celsius model = Celsius.getInstance();

    public LiveData<String> getFahrenheit() {
        return model.getFahrenheit();
    }

    public LiveData<String> getReamur() {
        return model.getReamur();
    }

    public void calculateTemperature(String celsiusText) {
        if (celsiusText == null || celsiusText.isEmpty()) {
            celsiusText = "0";
        }

        double value = Double.parseDouble(celsiusText);
        model.setCelsius(value);
        model.toFahrenheit();
        model.toReamur();
    }
}
