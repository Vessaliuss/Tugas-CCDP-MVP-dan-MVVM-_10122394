package ac.id.unikom.tryccdp.biodata;

public class Biodata {

    public static String getNama() {
        return "Muhammad Naufal Hilman";
    }

    public static String getNIM() {
        return "10122394";
    }

    public static String getKelas() {
        return "IF-11";
    }

    public static String getProdi() {
        return "Informatika";
    }

    public static String getUniversitas() {
        return "Universitas Komputer Indonesia";
    }
}
